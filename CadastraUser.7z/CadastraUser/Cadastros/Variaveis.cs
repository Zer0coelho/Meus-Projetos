﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastros
{
    public static class Variaveis
    {


        // Se usar SQL Server Express:
        public static string strConn = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=db_Cadastro;User ID=sa;Password=123456;";
    }
}
