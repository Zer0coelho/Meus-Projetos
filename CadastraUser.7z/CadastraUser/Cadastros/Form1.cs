﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cadastros
{
    public partial class form_Cadastros : Form
    {
        public string consulta;
        public string sql;
        public string caminhoImagem;
        public string ID_Estado;
        public form_Cadastros()
        {
            InitializeComponent();
        }

        private void form_Cadastros_Load(object sender, EventArgs e)
        {
            //Carrega ComboBox com método da classe CarregaComboBox e Lista:
            consulta = "SELECT Estado FROM tbl_estados;";
            CarregaComboBox carregaEstado = new CarregaComboBox();

            //Criar objeto de lista para armazenar os dados dos livros:
            List<string> Estado = new List<string>();
            Estado.AddRange(carregaEstado.carregaComboBoxEstado(consulta, "Estado"));

            //Copia dados da lsita para o ComboBox:
            cmb_Estado.Items.AddRange(Estado.ToArray());
        }

        private void txt_Nome_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Senha_Click(object sender, EventArgs e)
        {
            if (txt_Senha.PasswordChar == '*')
            {
                txt_Senha.PasswordChar = '\0';
                txt_RepeteSenha.PasswordChar = '\0';
                btn_Senha.Text = "Oculta Senha";
            }
            else
            {
                txt_Senha.PasswordChar = '*';
                txt_RepeteSenha.PasswordChar = '*';
                btn_Senha.Text = "Exibir Senha";
            }
        }

        private void btn_cadastro_Click(object sender, EventArgs e)
        {
            if (txt_Senha.Text.Equals(txt_RepeteSenha.Text))
            {
                Criptografar cripto = new Criptografar();
                string senha = cripto.HashSHA256(txt_Senha.Text);

                //Criar string SQL:
                string sql = "INSERT INTO tbl_usuarios(Nome, Sobrenome, Nome_user, RG, CPF, Senha, Imagem, ID_Estado) VALUES ('" + txt_Nome.Text + "','" + txt_Sobrenome.Text + "','" + txt_NomeUser.Text + "','" + txt_RG.Text + "','" + txt_CPF.Text + "','" + senha + "','" + caminhoImagem + "'," + Int16.Parse(ID_Estado) + ")";
                //MessageBox.Show(sql);
                ComandosDML inserir = new ComandosDML();
                try
                {
                    inserir.iud(sql);
                    MessageBox.Show("Usuário Cadastrado");
                }
                catch (SqlException s)
                {
                    MessageBox.Show(s.Source.ToString());
                }
            }
            else
            {
                MessageBox.Show("As senha digitadas não correspondem", "Senha inválida");
            }

            //Certificar CPF
            string cpf = txt_CPF.Text.Replace(".", "").Replace("-", "");
            int[] cpf_digitos = new int[11];

            if (cpf.Length != 11)
            {
                MessageBox.Show("CPF deve ter 11 dígitos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            for (int i = 0; i < 11; i++)
            {
                if (char.IsDigit(cpf[i]))
                {
                    cpf_digitos[i] = Convert.ToInt32(cpf[i].ToString());
                }
                else
                {
                    MessageBox.Show("CPF deve conter apenas números.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            if (!ValidaCPF(cpf_digitos))
            {
                MessageBox.Show("CPF inválido!", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Certificar RG
            string rg = txt_RG.Text.Replace(".", "").Replace("-", "");

            if (rg.Length != 9 || !long.TryParse(rg, out _))
            {
                MessageBox.Show("RG deve ter 9 dígitos e conter apenas números.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!ValidaRG(rg))
            {
                MessageBox.Show("RG inválido!", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }
        //Validação de CPF
        private bool ValidaCPF(int[] num)
        {
            int i, j, soma, resto, dv1, dv2;

            // Dígito verificador #1
            soma = 0;
            j = 10;

            for (i = 0; i < 9; i++)
            {
                soma += num[i] * j;
                j -= 1;
            }

            resto = soma % 11;

            if (resto < 2)
            {
                dv1 = 0;
            }
            else
            {
                dv1 = 11 - resto;
            }

            // Dígito verificador #2
            soma = 0;
            j = 11;

            for (i = 0; i < 10; i++)
            {
                soma += num[i] * j;
                j -= 1;
            }

            resto = soma % 11;

            if (resto < 2)
            {
                dv2 = 0;
            }
            else
            {
                dv2 = 11 - resto;
            }

            return num[9] == dv1 && num[10] == dv2;
        }
        //Validação de RG
        private bool ValidaRG(string rg)
        {
            int[] weights = { 2, 3, 4, 5, 6, 7, 8, 9 };
            int sum = 0;

            for (int i = 0; i < weights.Length; i++)
            {
                sum += (rg[i] - '0') * weights[i];
            }

            int calculatedDigit = 11 - (sum % 11);
            if (calculatedDigit == 10 || calculatedDigit == 11)
            {
                calculatedDigit = 0;
            }

            int actualDigit = rg[8] - '0';

            return calculatedDigit == actualDigit;
        }
        public void verificaEstadoSelecionado(string SQLconsultaEditora)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            conn.Open();
            SqlCommand comando = new SqlCommand(SQLconsultaEditora, conn);
            SqlDataReader drDados = null;
            drDados = comando.ExecuteReader();
            if (drDados.HasRows)
            {
                while (drDados.Read())
                {
                    ID_Estado = drDados["ID_Estado"].ToString();
                }
            }
            else
            {
                MessageBox.Show("Código não encontrado");
            }
            drDados.Close();
            conn.Close();
        }
        private void cmb_Estado_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Verifica Autor selecionado:
            string nomeCompletoEstado = cmb_Estado.SelectedItem.ToString();
            string consultaEstado = "SELECT ID_Estado FROM tbl_Estados WHERE Estado = '" + cmb_Estado.SelectedItem.ToString() + "'";
            //MessageBox.Show(consultaEstado);
            verificaEstadoSelecionado(consultaEstado);
        }

        private void btnTeste_Click(object sender, EventArgs e)
        {
           
        }

        private void btnEscolheImagem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            caminhoImagem = openFileDialog1.FileName;
            picBoxUser.ImageLocation = caminhoImagem;
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
    
}
