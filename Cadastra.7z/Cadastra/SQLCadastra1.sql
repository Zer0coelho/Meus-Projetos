-- Criar banco de dados db_Cadastro
CREATE DATABASE db_Cadastro ON PRIMARY
(NAME = db_Cadastro,
FILENAME = 'C:\SQL\db_Cadastro.mdf',
SIZE = 6MB,
MAXSIZE = 15MB,
FILEGROWTH = 10%)
LOG ON (
NAME = db_cadastro_log,
FILENAME = 'C:\SQL\db_Cadastro_log.ldf',
SIZE = 1MB, FILEGROWTH = 1MB)
GO

--Alterar o banco de dados em uso
USE db_Cadastro
GO

CREATE TABLE tbl_estados(
ID_Estado TINYINT PRIMARY KEY IDENTITY(1,1),
Estado CHAR(2) NOT NULL
);

--Adicionando as siglas dos Estados
INSERT INTO tbl_estados (Estado)
VALUES
('AC'), ('AL'), ('AM'), ('AP'), ('BA'), ('CE'), ('DF'), ('ES'), ('GO'), ('MA'), ('MT'), ('MS'), ('MG'), ('PA'), ('PB'), ('PR'),
('PE'), ('PI'), ('RJ'), ('RN'), ('RS'), ('RO'), ('RR'), ('SC'), ('SP'), ('SE'), ('TO');


-- Criar a tabela de usu�rios
CREATE TABLE tbl_usuarios (
ID_User SMALLINT PRIMARY KEY IDENTITY(1,1),
Nome VARCHAR(50) NOT NULL,
Sobrenome VARCHAR(50) NOT NULL,
Nome_user VARCHAR(50) NOT NULL UNIQUE,
Senha VARCHAR(255) NOT NULL,
RG CHAR(9) NOT NULL UNIQUE,
CPF CHAR(11) NOT NULL UNIQUE,
ID_Estado TINYINT NOT NULL,
Imagem VARCHAR(30),
CONSTRAINT fk_ID_Estado FOREIGN KEY (ID_Estado)
	REFERENCES tbl_estados (ID_Estado) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

SELECT * FROM tbl_usuarios;
SELECT Estado FROM tbl_estados;
ALTER TABLE tbl_usuarios
ALTER COLUMN Imagem VARCHAR(100);


SELECT Sobrenome, Nome_user, RG, CPF, Estado, Imagem
FROM tbl_usuarios U
INNER JOIN tbl_estados E
	ON U.ID_Estado = E.ID_Estado 
WHERE  Nome = 'gui';

