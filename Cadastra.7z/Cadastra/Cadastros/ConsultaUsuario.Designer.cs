﻿namespace Cadastros
{
    partial class ConsultaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblConsultaUser = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnConsulta = new System.Windows.Forms.Button();
            this.lblSobrenome = new System.Windows.Forms.Label();
            this.lblResSobrenome = new System.Windows.Forms.Label();
            this.lblNomeUser = new System.Windows.Forms.Label();
            this.lblResNomeUser = new System.Windows.Forms.Label();
            this.lblRG = new System.Windows.Forms.Label();
            this.lblResRG = new System.Windows.Forms.Label();
            this.lblCPF = new System.Windows.Forms.Label();
            this.lblResCPF = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.lblResEstado = new System.Windows.Forms.Label();
            this.picImagemUser = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picImagemUser)).BeginInit();
            this.SuspendLayout();
            // 
            // lblConsultaUser
            // 
            this.lblConsultaUser.AutoSize = true;
            this.lblConsultaUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsultaUser.Location = new System.Drawing.Point(12, 26);
            this.lblConsultaUser.Name = "lblConsultaUser";
            this.lblConsultaUser.Size = new System.Drawing.Size(399, 16);
            this.lblConsultaUser.TabIndex = 0;
            this.lblConsultaUser.Text = "Consultar Usuários cadastrados de acordo com o Nome.";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 83);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(92, 13);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome de Usuário:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(133, 80);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(139, 20);
            this.txtNome.TabIndex = 2;
            // 
            // btnConsulta
            // 
            this.btnConsulta.Location = new System.Drawing.Point(339, 64);
            this.btnConsulta.Name = "btnConsulta";
            this.btnConsulta.Size = new System.Drawing.Size(102, 51);
            this.btnConsulta.TabIndex = 3;
            this.btnConsulta.Text = "Cosultar";
            this.btnConsulta.UseVisualStyleBackColor = true;
            this.btnConsulta.Click += new System.EventHandler(this.btnConsulta_Click);
            // 
            // lblSobrenome
            // 
            this.lblSobrenome.AutoSize = true;
            this.lblSobrenome.Location = new System.Drawing.Point(12, 134);
            this.lblSobrenome.Name = "lblSobrenome";
            this.lblSobrenome.Size = new System.Drawing.Size(118, 13);
            this.lblSobrenome.TabIndex = 1;
            this.lblSobrenome.Text = "Sobrenome de Usuário:";
            // 
            // lblResSobrenome
            // 
            this.lblResSobrenome.AutoSize = true;
            this.lblResSobrenome.Location = new System.Drawing.Point(136, 134);
            this.lblResSobrenome.Name = "lblResSobrenome";
            this.lblResSobrenome.Size = new System.Drawing.Size(0, 13);
            this.lblResSobrenome.TabIndex = 1;
            this.lblResSobrenome.Click += new System.EventHandler(this.lblResSobrenome_Click);
            // 
            // lblNomeUser
            // 
            this.lblNomeUser.AutoSize = true;
            this.lblNomeUser.Location = new System.Drawing.Point(12, 174);
            this.lblNomeUser.Name = "lblNomeUser";
            this.lblNomeUser.Size = new System.Drawing.Size(92, 13);
            this.lblNomeUser.TabIndex = 1;
            this.lblNomeUser.Text = "Nome de Usuário:";
            // 
            // lblResNomeUser
            // 
            this.lblResNomeUser.AutoSize = true;
            this.lblResNomeUser.Location = new System.Drawing.Point(130, 174);
            this.lblResNomeUser.Name = "lblResNomeUser";
            this.lblResNomeUser.Size = new System.Drawing.Size(0, 13);
            this.lblResNomeUser.TabIndex = 1;
            // 
            // lblRG
            // 
            this.lblRG.AutoSize = true;
            this.lblRG.Location = new System.Drawing.Point(12, 214);
            this.lblRG.Name = "lblRG";
            this.lblRG.Size = new System.Drawing.Size(26, 13);
            this.lblRG.TabIndex = 1;
            this.lblRG.Text = "RG:";
            // 
            // lblResRG
            // 
            this.lblResRG.AutoSize = true;
            this.lblResRG.Location = new System.Drawing.Point(130, 214);
            this.lblResRG.Name = "lblResRG";
            this.lblResRG.Size = new System.Drawing.Size(0, 13);
            this.lblResRG.TabIndex = 1;
            // 
            // lblCPF
            // 
            this.lblCPF.AutoSize = true;
            this.lblCPF.Location = new System.Drawing.Point(12, 246);
            this.lblCPF.Name = "lblCPF";
            this.lblCPF.Size = new System.Drawing.Size(30, 13);
            this.lblCPF.TabIndex = 1;
            this.lblCPF.Text = "CPF:";
            // 
            // lblResCPF
            // 
            this.lblResCPF.AutoSize = true;
            this.lblResCPF.Location = new System.Drawing.Point(130, 246);
            this.lblResCPF.Name = "lblResCPF";
            this.lblResCPF.Size = new System.Drawing.Size(0, 13);
            this.lblResCPF.TabIndex = 1;
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(12, 282);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(43, 13);
            this.lblEstado.TabIndex = 1;
            this.lblEstado.Text = "Estado:";
            // 
            // lblResEstado
            // 
            this.lblResEstado.AutoSize = true;
            this.lblResEstado.Location = new System.Drawing.Point(130, 282);
            this.lblResEstado.Name = "lblResEstado";
            this.lblResEstado.Size = new System.Drawing.Size(0, 13);
            this.lblResEstado.TabIndex = 1;
            // 
            // picImagemUser
            // 
            this.picImagemUser.Location = new System.Drawing.Point(511, 53);
            this.picImagemUser.Name = "picImagemUser";
            this.picImagemUser.Size = new System.Drawing.Size(198, 134);
            this.picImagemUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picImagemUser.TabIndex = 4;
            this.picImagemUser.TabStop = false;
            this.picImagemUser.Click += new System.EventHandler(this.picImagemUser_Click);
            // 
            // ConsultaUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.picImagemUser);
            this.Controls.Add(this.btnConsulta);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblResSobrenome);
            this.Controls.Add(this.lblResNomeUser);
            this.Controls.Add(this.lblResRG);
            this.Controls.Add(this.lblResCPF);
            this.Controls.Add(this.lblResEstado);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblCPF);
            this.Controls.Add(this.lblRG);
            this.Controls.Add(this.lblNomeUser);
            this.Controls.Add(this.lblSobrenome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblConsultaUser);
            this.Name = "ConsultaUsuario";
            this.Text = "ConsultaUsuario";
            this.Load += new System.EventHandler(this.ConsultaUsuario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picImagemUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblConsultaUser;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnConsulta;
        private System.Windows.Forms.Label lblSobrenome;
        private System.Windows.Forms.Label lblResSobrenome;
        private System.Windows.Forms.Label lblNomeUser;
        private System.Windows.Forms.Label lblResNomeUser;
        private System.Windows.Forms.Label lblRG;
        private System.Windows.Forms.Label lblResRG;
        private System.Windows.Forms.Label lblCPF;
        private System.Windows.Forms.Label lblResCPF;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label lblResEstado;
        private System.Windows.Forms.PictureBox picImagemUser;
    }
}