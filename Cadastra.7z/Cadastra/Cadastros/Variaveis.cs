﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastros
{
    public static class Variaveis
    {
        public static string ConsultaSelecionada { get; set; }
        public static string CaixaTxtNomeUsuario { get; set; }
        //public static string CaixaTxtNome { get; set; }
        public static string CaixaTxtSobrenome { get; set; }
        public static string CaixaTxtRG { get; set; }
        public static string CaixaTxtCPF { get; set; }
        public static string CaixaTxtEstado { get; set; }
        public static string CaixaTxtImagem { get; set; }

        // Se usar SQL Server Express:
        public static string strConn = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=db_Cadastro;User ID=sa;Password=123456;";
    }
}
