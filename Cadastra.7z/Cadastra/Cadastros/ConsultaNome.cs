﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastros
{
    class ConsultaNome
    {
        public void fazerConsulta(string consulta)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            try
            {
                //Abrir a conexão com o banco de dados:
                conn.Open();
                //Criar comando de consulta:
                SqlCommand comando = new SqlCommand(consulta, conn);
                //Criar o DataReader:
                SqlDataReader drDados = null;
                //Executar a consulta:
                drDados = comando.ExecuteReader();
                if (drDados.HasRows) //Verificar se há linhas retornadas
                {
                    while (drDados.Read())
                    {
                        //Obter os resultados das colunas
                        Variaveis.CaixaTxtNomeUsuario = (string)drDados["Nome_user"];
                        Variaveis.CaixaTxtRG = (string)drDados["RG"];
                        Variaveis.CaixaTxtSobrenome = (string)drDados["Sobrenome"];
                        Variaveis.CaixaTxtCPF = (string)drDados["CPF"];
                        Variaveis.CaixaTxtEstado = (string)drDados["Estado"];
                        // Verificação se a coluna "Imagem" existe e não é nula
                        if (drDados["Imagem"] != DBNull.Value)
                        {
                            Variaveis.CaixaTxtImagem = (string)drDados["Imagem"];
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Código não encontrado");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
        }
    }
}
