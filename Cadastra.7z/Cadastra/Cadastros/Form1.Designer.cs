﻿namespace Cadastros
{
    partial class form_Cadastros
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Sobrenome = new System.Windows.Forms.Label();
            this.lbl_NomeUser = new System.Windows.Forms.Label();
            this.lbl_Senha = new System.Windows.Forms.Label();
            this.lbl_RG = new System.Windows.Forms.Label();
            this.lbl_CPF = new System.Windows.Forms.Label();
            this.lbl_Estado = new System.Windows.Forms.Label();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.txt_Sobrenome = new System.Windows.Forms.TextBox();
            this.txt_NomeUser = new System.Windows.Forms.TextBox();
            this.txt_Senha = new System.Windows.Forms.TextBox();
            this.btn_Senha = new System.Windows.Forms.Button();
            this.txt_RG = new System.Windows.Forms.TextBox();
            this.txt_CPF = new System.Windows.Forms.TextBox();
            this.cmb_Estado = new System.Windows.Forms.ComboBox();
            this.btn_cadastro = new System.Windows.Forms.Button();
            this.lbl_RepeteSenha = new System.Windows.Forms.Label();
            this.txt_RepeteSenha = new System.Windows.Forms.TextBox();
            this.picBoxUser = new System.Windows.Forms.PictureBox();
            this.btnEscolheImagem = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(399, 39);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(60, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Seu Nome:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cadastro de Usuários";
            // 
            // lbl_Sobrenome
            // 
            this.lbl_Sobrenome.AutoSize = true;
            this.lbl_Sobrenome.Location = new System.Drawing.Point(399, 94);
            this.lbl_Sobrenome.Name = "lbl_Sobrenome";
            this.lbl_Sobrenome.Size = new System.Drawing.Size(86, 13);
            this.lbl_Sobrenome.TabIndex = 0;
            this.lbl_Sobrenome.Text = "Seu Sobrenome:";
            // 
            // lbl_NomeUser
            // 
            this.lbl_NomeUser.AutoSize = true;
            this.lbl_NomeUser.Location = new System.Drawing.Point(399, 145);
            this.lbl_NomeUser.Name = "lbl_NomeUser";
            this.lbl_NomeUser.Size = new System.Drawing.Size(114, 13);
            this.lbl_NomeUser.TabIndex = 0;
            this.lbl_NomeUser.Text = "Seu Nome de Usuário:";
            // 
            // lbl_Senha
            // 
            this.lbl_Senha.AutoSize = true;
            this.lbl_Senha.Location = new System.Drawing.Point(399, 194);
            this.lbl_Senha.Name = "lbl_Senha";
            this.lbl_Senha.Size = new System.Drawing.Size(41, 13);
            this.lbl_Senha.TabIndex = 0;
            this.lbl_Senha.Text = "Senha:";
            // 
            // lbl_RG
            // 
            this.lbl_RG.AutoSize = true;
            this.lbl_RG.Location = new System.Drawing.Point(399, 294);
            this.lbl_RG.Name = "lbl_RG";
            this.lbl_RG.Size = new System.Drawing.Size(26, 13);
            this.lbl_RG.TabIndex = 0;
            this.lbl_RG.Text = "RG:";
            // 
            // lbl_CPF
            // 
            this.lbl_CPF.AutoSize = true;
            this.lbl_CPF.Location = new System.Drawing.Point(399, 345);
            this.lbl_CPF.Name = "lbl_CPF";
            this.lbl_CPF.Size = new System.Drawing.Size(30, 13);
            this.lbl_CPF.TabIndex = 0;
            this.lbl_CPF.Text = "CPF:";
            // 
            // lbl_Estado
            // 
            this.lbl_Estado.AutoSize = true;
            this.lbl_Estado.Location = new System.Drawing.Point(399, 400);
            this.lbl_Estado.Name = "lbl_Estado";
            this.lbl_Estado.Size = new System.Drawing.Size(43, 13);
            this.lbl_Estado.TabIndex = 0;
            this.lbl_Estado.Text = "Estado:";
            // 
            // txt_Nome
            // 
            this.txt_Nome.Location = new System.Drawing.Point(402, 55);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(178, 20);
            this.txt_Nome.TabIndex = 2;
            this.txt_Nome.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // txt_Sobrenome
            // 
            this.txt_Sobrenome.Location = new System.Drawing.Point(402, 110);
            this.txt_Sobrenome.Name = "txt_Sobrenome";
            this.txt_Sobrenome.Size = new System.Drawing.Size(178, 20);
            this.txt_Sobrenome.TabIndex = 2;
            this.txt_Sobrenome.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // txt_NomeUser
            // 
            this.txt_NomeUser.Location = new System.Drawing.Point(402, 161);
            this.txt_NomeUser.Name = "txt_NomeUser";
            this.txt_NomeUser.Size = new System.Drawing.Size(178, 20);
            this.txt_NomeUser.TabIndex = 2;
            this.txt_NomeUser.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // txt_Senha
            // 
            this.txt_Senha.Location = new System.Drawing.Point(402, 210);
            this.txt_Senha.Name = "txt_Senha";
            this.txt_Senha.PasswordChar = '*';
            this.txt_Senha.Size = new System.Drawing.Size(178, 20);
            this.txt_Senha.TabIndex = 2;
            this.txt_Senha.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // btn_Senha
            // 
            this.btn_Senha.Location = new System.Drawing.Point(586, 210);
            this.btn_Senha.Name = "btn_Senha";
            this.btn_Senha.Size = new System.Drawing.Size(95, 23);
            this.btn_Senha.TabIndex = 3;
            this.btn_Senha.Text = "Mostrar Senha";
            this.btn_Senha.UseVisualStyleBackColor = true;
            this.btn_Senha.Click += new System.EventHandler(this.btn_Senha_Click);
            // 
            // txt_RG
            // 
            this.txt_RG.Location = new System.Drawing.Point(402, 310);
            this.txt_RG.Name = "txt_RG";
            this.txt_RG.Size = new System.Drawing.Size(178, 20);
            this.txt_RG.TabIndex = 2;
            this.txt_RG.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // txt_CPF
            // 
            this.txt_CPF.Location = new System.Drawing.Point(402, 361);
            this.txt_CPF.Name = "txt_CPF";
            this.txt_CPF.Size = new System.Drawing.Size(178, 20);
            this.txt_CPF.TabIndex = 2;
            this.txt_CPF.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // cmb_Estado
            // 
            this.cmb_Estado.FormattingEnabled = true;
            this.cmb_Estado.Location = new System.Drawing.Point(402, 416);
            this.cmb_Estado.Name = "cmb_Estado";
            this.cmb_Estado.Size = new System.Drawing.Size(178, 21);
            this.cmb_Estado.TabIndex = 4;
            this.cmb_Estado.SelectedIndexChanged += new System.EventHandler(this.cmb_Estado_SelectedIndexChanged);
            // 
            // btn_cadastro
            // 
            this.btn_cadastro.Location = new System.Drawing.Point(423, 461);
            this.btn_cadastro.Name = "btn_cadastro";
            this.btn_cadastro.Size = new System.Drawing.Size(114, 49);
            this.btn_cadastro.TabIndex = 3;
            this.btn_cadastro.Text = "Cadastrar";
            this.btn_cadastro.UseVisualStyleBackColor = true;
            this.btn_cadastro.Click += new System.EventHandler(this.btn_cadastro_Click);
            // 
            // lbl_RepeteSenha
            // 
            this.lbl_RepeteSenha.AutoSize = true;
            this.lbl_RepeteSenha.Location = new System.Drawing.Point(401, 245);
            this.lbl_RepeteSenha.Name = "lbl_RepeteSenha";
            this.lbl_RepeteSenha.Size = new System.Drawing.Size(152, 13);
            this.lbl_RepeteSenha.TabIndex = 0;
            this.lbl_RepeteSenha.Text = "Repita a senha para confirmar:";
            // 
            // txt_RepeteSenha
            // 
            this.txt_RepeteSenha.Location = new System.Drawing.Point(402, 261);
            this.txt_RepeteSenha.Name = "txt_RepeteSenha";
            this.txt_RepeteSenha.PasswordChar = '*';
            this.txt_RepeteSenha.Size = new System.Drawing.Size(178, 20);
            this.txt_RepeteSenha.TabIndex = 2;
            this.txt_RepeteSenha.TextChanged += new System.EventHandler(this.txt_Nome_TextChanged);
            // 
            // picBoxUser
            // 
            this.picBoxUser.Location = new System.Drawing.Point(59, 78);
            this.picBoxUser.Name = "picBoxUser";
            this.picBoxUser.Size = new System.Drawing.Size(209, 203);
            this.picBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxUser.TabIndex = 5;
            this.picBoxUser.TabStop = false;
            this.picBoxUser.Click += new System.EventHandler(this.picBoxUser_Click);
            // 
            // btnEscolheImagem
            // 
            this.btnEscolheImagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEscolheImagem.Location = new System.Drawing.Point(106, 300);
            this.btnEscolheImagem.Name = "btnEscolheImagem";
            this.btnEscolheImagem.Size = new System.Drawing.Size(111, 46);
            this.btnEscolheImagem.TabIndex = 6;
            this.btnEscolheImagem.Text = "Escolhe Imagem";
            this.btnEscolheImagem.UseVisualStyleBackColor = true;
            this.btnEscolheImagem.Click += new System.EventHandler(this.btnEscolheImagem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.consultarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // consultarToolStripMenuItem
            // 
            this.consultarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuáriosToolStripMenuItem});
            this.consultarToolStripMenuItem.Name = "consultarToolStripMenuItem";
            this.consultarToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.consultarToolStripMenuItem.Text = "Consultar";
            // 
            // usuáriosToolStripMenuItem
            // 
            this.usuáriosToolStripMenuItem.Name = "usuáriosToolStripMenuItem";
            this.usuáriosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.usuáriosToolStripMenuItem.Text = "Usuários";
            this.usuáriosToolStripMenuItem.Click += new System.EventHandler(this.usuáriosToolStripMenuItem_Click);
            // 
            // form_Cadastros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 577);
            this.Controls.Add(this.btnEscolheImagem);
            this.Controls.Add(this.picBoxUser);
            this.Controls.Add(this.cmb_Estado);
            this.Controls.Add(this.btn_cadastro);
            this.Controls.Add(this.btn_Senha);
            this.Controls.Add(this.txt_CPF);
            this.Controls.Add(this.txt_RG);
            this.Controls.Add(this.txt_RepeteSenha);
            this.Controls.Add(this.txt_Senha);
            this.Controls.Add(this.txt_NomeUser);
            this.Controls.Add(this.txt_Sobrenome);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Estado);
            this.Controls.Add(this.lbl_CPF);
            this.Controls.Add(this.lbl_RG);
            this.Controls.Add(this.lbl_RepeteSenha);
            this.Controls.Add(this.lbl_Senha);
            this.Controls.Add(this.lbl_NomeUser);
            this.Controls.Add(this.lbl_Sobrenome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "form_Cadastros";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.form_Cadastros_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxUser)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Sobrenome;
        private System.Windows.Forms.Label lbl_NomeUser;
        private System.Windows.Forms.Label lbl_Senha;
        private System.Windows.Forms.Label lbl_RG;
        private System.Windows.Forms.Label lbl_CPF;
        private System.Windows.Forms.Label lbl_Estado;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.TextBox txt_Sobrenome;
        private System.Windows.Forms.TextBox txt_NomeUser;
        private System.Windows.Forms.TextBox txt_Senha;
        private System.Windows.Forms.Button btn_Senha;
        private System.Windows.Forms.TextBox txt_RG;
        private System.Windows.Forms.TextBox txt_CPF;
        private System.Windows.Forms.ComboBox cmb_Estado;
        private System.Windows.Forms.Button btn_cadastro;
        private System.Windows.Forms.Label lbl_RepeteSenha;
        private System.Windows.Forms.TextBox txt_RepeteSenha;
        private System.Windows.Forms.PictureBox picBoxUser;
        private System.Windows.Forms.Button btnEscolheImagem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuáriosToolStripMenuItem;
    }
}

