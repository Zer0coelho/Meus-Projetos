﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cadastros
{
    public partial class ConsultaUsuario : Form
    {
        public string consulta;
        public string sql;
        //public string IDEditora;
        public string consultaUsuario;
        public ConsultaUsuario()
        {
            InitializeComponent();
        }

        private void ConsultaUsuario_Load(object sender, EventArgs e)
        {

        }

        private void lblResSobrenome_Click(object sender, EventArgs e)
        {

        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            //Consulta a ser realizada:
            consulta = "SELECT Sobrenome, Nome_user, RG, CPF, Estado, Imagem FROM tbl_usuarios U INNER JOIN tbl_estados E ON U.ID_Estado = E.ID_Estado WHERE Nome = '" + txtNome.Text + "'";
            //MessageBox.Show(consulta);
            //Instanciar classe que realiza a consulta:
            ConsultaNome consultaNome = new ConsultaNome();

            //Passar a string SQL para o método fazerConsulta()
            consultaNome.fazerConsulta(consulta);

            //Mostrar os resultados nas caixas de texto;
            lblResSobrenome.Text = Variaveis.CaixaTxtSobrenome;
            lblResNomeUser.Text = Variaveis.CaixaTxtNomeUsuario;
            lblResRG.Text = Variaveis.CaixaTxtRG;
            lblResCPF.Text = Variaveis.CaixaTxtCPF;
            lblResEstado.Text = Variaveis.CaixaTxtEstado;
            picImagemUser.ImageLocation = Variaveis.CaixaTxtImagem;

        }

        private void picImagemUser_Click(object sender, EventArgs e)
        {

        }
    }
}
